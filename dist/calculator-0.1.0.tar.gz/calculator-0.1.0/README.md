# calculator

This is a basic calculator that supports addition, substraction and product of two numbers.

This project is used for a demo CI/CD pipeline using Jenkins
